function XY = top(s)
    X = s;
    Y = 1-3*s+3*s^2;
    XY = [X Y];
end