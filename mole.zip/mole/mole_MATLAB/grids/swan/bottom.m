function XY = bottom(s)
    X = s;
    Y = 0;
    XY = [X Y];
end