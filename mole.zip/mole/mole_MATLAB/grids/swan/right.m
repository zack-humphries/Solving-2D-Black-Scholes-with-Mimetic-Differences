function XY = right(s)
    X = 1+2*s-2*s^2;
    Y = s;
    XY = [X Y];
end