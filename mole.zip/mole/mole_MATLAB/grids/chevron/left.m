function XY = left(s)
    X = 0;
    Y = s;
    XY = [X Y];
end