function XY = right(s)
    X = 0;
    Y = -1-s;
    XY = [X Y];
end