function XY = top(s)
    X = 4*cos(pi/2*(1-2*s));
    Y = 2*sin(pi/2*(1-2*s));
    XY = [X Y];
end