First off, thank you for considering contributing to MOLE. It’s people like you that make MOLE such a great library. 
If you want to contribute to this project, please shoot an email to johnnycorbino@gmail.com. Thanks! =)
